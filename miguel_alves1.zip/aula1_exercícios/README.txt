EXERCÍCIOS — AULA 1

Esta pasta é independente do projeto Flask.

Execute os arquivos nesta ordem, pelo terminal aberto nesta pasta:

  python criar_banco.py
  python inserir.py
  python consultar.py

O criar_banco.py cria o arquivo livraria.db e a tabela livros.
O inserir.py cadastra cinco livros usando executemany() e parâmetros ?.
O consultar.py lista os livros por ano e conta os que foram publicados
depois de 1900.

Para conferir a persistência, feche o terminal, abra outro nesta mesma
pasta e execute:

  python consultar.py

Não execute inserir.py novamente durante esse teste, para não cadastrar
os mesmos livros outra vez.

O arquivo consulta_colunas.py mostra o resultado de SELECT titulo, autor
FROM livros, como pede o item c do desafio.
A conclusão do exercício 4 está em CONCLUSAO.txt.
