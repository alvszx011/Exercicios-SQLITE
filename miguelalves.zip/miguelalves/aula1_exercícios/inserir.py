import sqlite3

livros = [
    ("Dom Casmurro", "Machado de Assis", 1899, 39.90),
    ("O Alienista", "Machado de Assis", 1882, 29.90),
    ("A Revolução dos Bichos", "George Orwell", 1945, 34.50),
    ("1984", "George Orwell", 1949, 42.00),
    ("O Hobbit", "J. R. R. Tolkien", 1937, 49.90),
]

conn = sqlite3.connect("livraria.db")
cursor = conn.cursor()

cursor.executemany(
    "INSERT INTO livros (titulo, autor, ano, preco) VALUES (?, ?, ?, ?)",
    livros
)

conn.commit()
print(f"{len(livros)} livros foram cadastrados com sucesso!")
conn.close()
