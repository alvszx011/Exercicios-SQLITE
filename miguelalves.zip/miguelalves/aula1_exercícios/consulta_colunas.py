import sqlite3

conn = sqlite3.connect("livraria.db")
cursor = conn.cursor()

cursor.execute("SELECT titulo, autor FROM livros ORDER BY ano ASC")
livros = cursor.fetchall()

for titulo, autor in livros:
    print(f'"{titulo}" — {autor}')

conn.close()
