import sqlite3

conn = sqlite3.connect("livraria.db")
conn.row_factory = sqlite3.Row
cursor = conn.cursor()

cursor.execute("SELECT * FROM livros ORDER BY ano ASC")
livros = cursor.fetchall()

for livro in livros:
    print(f'"{livro["titulo"]}" — {livro["autor"]}')

cursor.execute("SELECT * FROM livros WHERE ano > ?", (1900,))
encontrados = cursor.fetchall()
print(f"Quantidade de livros com ano maior que 1900: {len(encontrados)}")

conn.close()
